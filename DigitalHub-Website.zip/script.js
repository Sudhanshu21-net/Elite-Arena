function buy() {
    alert("Redirecting to payment...");
    window.location.href = "upi://pay?pa=gd79115@okicici&pn=DigitalHub&cu=INR";
}
